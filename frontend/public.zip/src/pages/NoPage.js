const NoPage = () => {
  return (
    <div>
      <h1 className="text-center" style={{ margin: 'auto' }}>404 Not found!</h1>
    </div>
  );
};

export default NoPage;
